[Verse 1]
Early one morning the ☀ was shining
I was laying in 🛏
Wondering if she＇d changed at all
If her hair was still 🔴
Her 💑 they said our lives together
Sure was going to be rough
They never did like Mama's homemade 👗
Papa's bankbook wasn't big enough
And I was standing on the side of the road
🌧 falling on my shoes
Heading out for the East Coast
Lord knows I've paid some dues
Getting through
Tangled up in 𝕌𝕟𝕚𝕔𝕠𝕕𝕖

[Verse 2]
She was married when we first met
Soon to be divorced
I helped her out of a jam, I guess
But I used a little too much force
We drove that car as far as we could
Abandoned it out West
Split up on a dark sad night
Both agreeing it was best
She turned around to look at me
As I was walking away
I heard her say over my shoulder
"We'll meet again someday
On the avenue"
Tangled up in 𝕌𝕟𝕚𝕔𝕠𝕕𝕖

[Verse 3]
I had a job in the great north woods
Working as a 👨🏽‍🍳 for a spell
But I never did like it all that much
And one day the ax just fell
So I drifted down to New Orleans
Where I lucky was to be employed
Working for a while on a fishing boat
Right outside of Delacroix
But all the while I was alone
The past was close behind
I seen a lot of women
But she never escaped my mind
And I just grew
Tangled up in 𝕌𝕟𝕚𝕔𝕠𝕕𝕖

[Verse 4]
She was working in a topless place
And I stopped in for a beer
I just kept looking at the side of her face
In the spotlight, so clear
And later on, when the crowd thinned out
I was just about to do the same
She was standing there, in back of my chair
Said to me "Don't I know your name?"
I muttered something underneath my breath
She studied the lines on my face
I must admit, I felt a little uneasy
When she bent down to 👔 the laces
Of my 👞
Tangled up in 𝕌𝕟𝕚𝕔𝕠𝕕𝕖

[Verse 5]~~~~
She lit a burner on the stove
And offered me a pipe
"I thought you'd never say hello" she said
"You look like the silent type"
Then she opened up a book of poems
And handed it to me
Written by an 🇮🇹 poet
From the thirteenth century
And every one of them words rang true
And glowed like burning coal
Pouring off of every page
Like it was written in my soul
From me to you
Tangled up in 𝕌𝕟𝕚𝕔𝕠𝕕𝕖

[Verse 6]
I lived with them on Montague Street
In a basement down the stairs
There was music in the cafes at 🌃
And revolution in the air
Then he started into dealing with slaves
And something inside of him died
She had to sell everything she owned
And froze up inside
And when it finally, the bottom fell out
I became withdrawn
The only thing I knew how to do
Was to keep on keeping on
Like a 🐦 that flew
Tangled up in 𝕌𝕟𝕚𝕔𝕠𝕕𝕖

[Verse 7]
So now I'm going back again
I got to get to her somehow
All the people we used to know
They're an illusion to me now
Some are 𝓜athematicians
Some are carpenter's wives
Don't know how it all got started
I don't know what they're doing with their lives
But me, I'm still on the road
A-heading for another joint
We always did feel the same
We just saw it from a different point
Of view
Tangled up in 𝕌𝕟𝕚𝕔𝕠𝕕𝕖